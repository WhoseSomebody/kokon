# Font Awesome Extension

## Font Awesome Extension now has 170 icons

Font Awesome Extension has changed the prefix from `fa-` to `fae`, because this was giving causing some problems with original Font Awesome icons project, and that is not the purpose of this project. If you find any bug, or if you need an icon please create an issue, and I will try to resolve this as soon as possible. Thank you!

